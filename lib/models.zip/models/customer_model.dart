import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart'; // Para ValueGetter en copyWith

class Customer {
  final String id;
  final String name; // Contacto
  final String businessName; // Negocio (¡asegúrate que exista en Firestore!)
  final String email;
  final String phone;
  final String address;
  final bool? isNewlyAssigned; // Nuevo campo para alerta
  final String? adminNote; // Nuevo campo para nota admin
  final bool? acknowledgedByVendor; // Nuevo campo para acuse recibo
  // Añade otros campos si los tienes (lat/lng, etc.)

  Customer({
    required this.id,
    required this.name,
    required this.businessName, // Importante
    required this.email,
    required this.phone,
    required this.address,
    this.isNewlyAssigned,
    this.adminNote,
    this.acknowledgedByVendor,
  });

  // Lee desde Firestore
  factory Customer.fromFirestore(DocumentSnapshot doc) {
    Map<String, dynamic> data = doc.data() as Map<String, dynamic>? ?? {};
    return Customer(
      id: doc.id,
      name: data['name'] ?? '',
      businessName: data['businessName'] ?? data['name'] ?? '', // Fallback por si no tienes businessName
      email: data['email'] ?? '',
      phone: data['phone'] ?? '',
      address: data['address'] ?? '',
      isNewlyAssigned: data['isNewlyAssigned'] as bool?,
      adminNote: data['adminNote'] as String?,
      acknowledgedByVendor: data['acknowledgedByVendor'] as bool?,
    );
  }

  // Método útil para actualizaciones de estado
  Customer copyWith({
    String? id, String? name, String? businessName, String? email, String? phone, String? address,
    bool? isNewlyAssigned, ValueGetter<String?>? adminNote, bool? acknowledgedByVendor,
  }) {
    return Customer(
      id: id ?? this.id, name: name ?? this.name, businessName: businessName ?? this.businessName,
      email: email ?? this.email, phone: phone ?? this.phone, address: address ?? this.address,
      isNewlyAssigned: isNewlyAssigned ?? this.isNewlyAssigned,
      adminNote: adminNote != null ? adminNote() : this.adminNote,
      acknowledgedByVendor: acknowledgedByVendor ?? this.acknowledgedByVendor,
    );
  }
}

// Extensión útil (puedes ponerla aquí o en helpers.dart)
extension CustomerExtensionsHelper on Customer {
  bool get isPendingAcknowledgement => (isNewlyAssigned ?? false) || !(acknowledgedByVendor ?? true);
}