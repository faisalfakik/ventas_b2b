import 'package:flutter/material.dart';

// Widget para banner de error no crítico (se muestra arriba del contenido)
class GeneralErrorBanner extends StatelessWidget {
  final String message;
  final VoidCallback onDismiss; // Callback para cerrar el banner
  const GeneralErrorBanner(
      {super.key, required this.message, required this.onDismiss});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      color: theme.colorScheme.errorContainer, // Color de fondo para errores
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      margin: const EdgeInsets.only(bottom: 8), // Margen para separarlo del contenido
      child: Row(
        children: [
          Icon(Icons.error_outline,
              color: theme.colorScheme.onErrorContainer, size: 18), // Color de texto/icono sobre fondo de error
          const SizedBox(width: 8),
          Expanded(
              child: Text(message,
                  style: TextStyle(color: theme.colorScheme.onErrorContainer))),
          IconButton(
            icon: Icon(Icons.close,
                size: 18, color: theme.colorScheme.onErrorContainer),
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(),
            onPressed: onDismiss, // Llama al callback para cerrar
            tooltip: 'Descartar mensaje',
          )
        ],
      ),
    );
  }
}

// Widget para estado de error crítico (ocupa toda la pantalla)
class ErrorStateWidget extends StatelessWidget {
  final String message;
  final VoidCallback onRetry; // Callback para el botón reintentar
  const ErrorStateWidget({super.key, required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.warning_amber_rounded,
                color: theme.colorScheme.error, size: 50), // Color de error principal
            const SizedBox(height: 16),
            Text(message,
                style: theme.textTheme.titleMedium, textAlign: TextAlign.center),
            const SizedBox(height: 24), // Más espacio antes del botón
            ElevatedButton.icon(
              icon: const Icon(Icons.refresh),
              label: const Text('Reintentar'),
              onPressed: onRetry, // Llama al callback para reintentar
              style: ElevatedButton.styleFrom(
                  backgroundColor: theme.colorScheme.primary, // Color primario para el botón
                  foregroundColor: theme.colorScheme.onPrimary), // Color de texto/icono sobre primario
            ),
          ],
        ),
      ),
    );
  }
}