import 'package:flutter/material.dart';

// Botón pequeño con icono para acciones rápidas en tarjetas
class QuickActionButton extends StatelessWidget {
  final IconData icon;
  final String tooltip;
  final VoidCallback onPressed;
  final Color? color; // Permite personalizar color opcionalmente

  const QuickActionButton({
    super.key,
    required this.icon,
    required this.tooltip,
    required this.onPressed,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return IconButton(
      icon: Icon(icon),
      iconSize: 20, // Tamaño estándar pequeño
      // Usa color pasado o el primario del tema
      color: color ?? theme.primaryColor,
      tooltip: tooltip,
      onPressed: onPressed,
      padding: const EdgeInsets.all(6), // Padding ajustado
      constraints: const BoxConstraints(), // Evita tamaño extra por defecto
      visualDensity: VisualDensity.compact, // Más compacto
      splashRadius: 20, // Radio del efecto splash
    );
  }
}