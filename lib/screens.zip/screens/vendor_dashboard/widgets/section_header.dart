import 'package:flutter/material.dart';

class SectionHeader extends StatelessWidget {
  final String title;
  final VoidCallback? onViewAllPressed; // Callback opcional para el botón "Ver Todos"

  const SectionHeader(this.title, {super.key, this.onViewAllPressed});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context); // Obtener tema del contexto
    final textTheme = theme.textTheme;

    return Padding(
      // Padding ajustado para alinear mejor visualmente
      padding: const EdgeInsets.only(left: 4, right: 0, bottom: 12.0, top: 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Título de la sección
          Text(
            title,
            style: textTheme.headlineSmall, // Estilo de cabecera
          ),
          // Botón "Ver Todos" (solo si se proporciona el callback)
          if (onViewAllPressed != null)
            TextButton(
              onPressed: onViewAllPressed,
              style: TextButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 4), // Padding ajustado
                  visualDensity: VisualDensity.compact // Más compacto
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                      'Ver Todos',
                      style: textTheme.bodySmall?.copyWith(color: theme.primaryColor) // Estilo
                  ),
                  const SizedBox(width: 4),
                  Icon(
                      Icons.arrow_forward_ios,
                      size: 12, // Icono pequeño
                      color: theme.primaryColor
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}