// lib/screens/vendor_dashboard/vendor_dashboard_screen.dart

// --- Framework & Packages ---
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
// import 'package:intl/intl.dart'; // Probablemente no se use aquí directamente
// import 'package:url_launcher/url_launcher.dart'; // Probablemente no se use aquí directamente

// --- ViewModel ---
// Desde la subcarpeta 'viewmodels' (ESTÁ BIEN ESTA RUTA)
import 'viewmodels/vendor_dashboard_viewmodel.dart';

// --- Modelos ---
// Sube DOS niveles (vendor_dashboard -> screens -> lib) y baja a 'models'
import '../../models/vendor_model.dart';   // Verifica que tu archivo se llame así (singular)
import '../../models/client_model.dart';    // Verifica que tu archivo se llame así
import '../../models/visit_model.dart';     // Verifica que tu archivo se llame así
import '../../models/sales_goal_model.dart';// Verifica que tu archivo se llame así

// --- Widgets Separados ---
// Desde la subcarpeta 'widgets' (ESTÁ BIEN ESTA RUTA)
import 'widgets/vendor_info_card.dart';
import 'widgets/sales_goal_card.dart';
import 'widgets/stats_panel.dart';
import 'widgets/section_header.dart';
import 'widgets/filter_chips.dart';
import 'widgets/visit_list.dart';
import 'widgets/customer_list.dart';
import 'widgets/error_widgets.dart';
// Nota: los widgets individuales como visit_card, etc. son importados por visit_list/customer_list

// --- Helpers/Utils ---
// Sube DOS niveles (vendor_dashboard -> screens -> lib) y baja a 'utils'
// import '../../utils/helpers.dart'; // Descomenta y verifica si lo usas aquí

// --- Otras Pantallas (Navegación) ---
// Sube UN nivel (vendor_dashboard -> screens)
import '../customer_detail_screen.dart';
import '../visit_detail_screen.dart';
import '../schedule_visit_screen.dart';
import '../../vendor_tools_screen.dart';

// --- Widget Principal (Proveedor del ViewModel) ---
class VendorDashboardScreen extends StatelessWidget {
  final String vendorId;
  const VendorDashboardScreen({super.key, required this.vendorId});

  @override
  Widget build(BuildContext context) {
    // Crea e inyecta el ViewModel usando ChangeNotifierProvider
    return ChangeNotifierProvider(
      create: (_) => VendorDashboardViewModel(vendorId: vendorId),
      // El child es la vista real que consumirá el ViewModel
      child: const _VendorDashboardView(),
    );
  }
}

// --- Widget de la Vista (Consume el ViewModel) ---
class _VendorDashboardView extends StatefulWidget {
  // Convertido a StatefulWidget para manejar el ScrollController
  const _VendorDashboardView();
  @override
  State<_VendorDashboardView> createState() => _VendorDashboardViewState();
}

class _VendorDashboardViewState extends State<_VendorDashboardView> {
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    // Añade listener para detectar scroll y cargar más (paginación infinita)
    _scrollController.addListener(_onScroll);
  }

  @override
  void dispose() {
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose(); // Importante liberar el controlador
    super.dispose();
  }

  // Lógica para cargar más cuando el usuario llega cerca del final
  void _onScroll() {
    // Umbral antes de llegar al final (ajusta según necesidad)
    const scrollThreshold = 300.0;
    if (_scrollController.position.pixels >=
        _scrollController.position.maxScrollExtent - scrollThreshold) {
      // Llama a los métodos del ViewModel para cargar más
      // Usa 'context.read' dentro de callbacks/listeners para evitar re-escuchar
      context.read<VendorDashboardViewModel>().loadMoreVisits();
      context.read<VendorDashboardViewModel>().loadMoreCustomers();
    }
  }

  // --- Métodos de Navegación (Usan context.read para acceder al ViewModel) ---
  void _navigateToScheduleVisit(BuildContext context) {
    final viewModel = context.read<VendorDashboardViewModel>();
    Navigator.push<bool>( context,
      MaterialPageRoute(builder: (_) => ScheduleVisitScreen(vendorId: viewModel.vendorId)),
    ).then((visitScheduled) {
      if (visitScheduled == true) viewModel.loadInitialData(refresh: true);
    });
  }
  void _navigateToCustomerDetail(BuildContext context, Customer customer) { // Pasar objeto completo
    final viewModel = context.read<VendorDashboardViewModel>();
    Navigator.push( context,
      MaterialPageRoute(builder: (_) => CustomerDetailScreen(
        customerId: customer.id,
        vendorId: viewModel.vendorId,
        // Opcional: Pasar el objeto cliente para no tener que buscarlo en la pantalla de detalle
        // initialCustomer: customer,
      )),
    );
  }
  void _navigateToVisitDetail(BuildContext context, Visit visit) { // Pasar objeto completo
    final viewModel = context.read<VendorDashboardViewModel>();
    // Pasar el cliente cacheado si existe
    final customer = viewModel.getCachedCustomer(visit.customerId);
    Navigator.push<bool>( context,
      MaterialPageRoute( builder: (_) => VisitDetailScreen(
        visitId: visit.id,
        // Opcional: Pasar objetos para evitar búsqueda en pantalla de detalle
        // initialVisit: visit,
        // initialCustomer: customer,
      )),
    ).then((visitUpdated) {
      if (visitUpdated == true) viewModel.loadInitialData(refresh: true);
    });
  }
  void _navigateToMap(BuildContext context) {
    print("TODO: Navegar a pantalla de mapa de visitas");
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Mapa no implementado aún')));
    // final viewModel = context.read<VendorDashboardViewModel>();
    // final visitsWithLocation = viewModel.displayVisits.where((v) => v.latitude != null).toList();
    // Navigator.push(context, MaterialPageRoute(builder: (_) => MapVisitsScreen(visits: visitsWithLocation)));
  }

  // --- Build Method Principal de la Vista ---
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    // Escucha cambios en el ViewModel para reconstruir la UI necesaria
    final viewModel = context.watch<VendorDashboardViewModel>();

    return Scaffold(
      appBar: AppBar(
        backgroundColor: theme.primaryColor,
        foregroundColor: theme.colorScheme.onPrimary,
        elevation: 1.0,
        title: _AppBarTitle(vendor: viewModel.vendor), // Widget separado para título
        actions: [
          _ConnectivityIcon(isOffline: viewModel.isOffline), // Widget separado
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'Refrescar Datos',
            onPressed: viewModel.isLoading ? null : () => viewModel.loadInitialData(refresh: true),
          ),
        ],
        // Indicador de progreso lineal en AppBar si está cargando en segundo plano
        bottom: viewModel.isLoading && viewModel.initialLoadComplete
            ? PreferredSize( preferredSize: const Size.fromHeight(4.0),
          child: LinearProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(theme.colorScheme.secondary),
            backgroundColor: theme.primaryColorDark?.withOpacity(0.5), // Más sutil
          ), )
            : null,
      ),
      // Usar RefreshIndicator para recarga manual
      body: RefreshIndicator(
        onRefresh: () => viewModel.loadInitialData(refresh: true),
        color: theme.primaryColor,
        child: _buildBodyScrollView(context, viewModel), // Construye el cuerpo
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _navigateToScheduleVisit(context),
        backgroundColor: theme.colorScheme.secondary,
        foregroundColor: theme.colorScheme.onSecondary,
        icon: const Icon(Icons.add_task_outlined),
        label: const Text('Agendar Visita'),
        tooltip: 'Programar Nueva Visita',
      ),
    );
  }

  // --- Construcción del Cuerpo ---
  Widget _buildBodyScrollView(BuildContext context, VendorDashboardViewModel viewModel) {

    // Estado de Carga Inicial
    if (viewModel.isLoading && !viewModel.initialLoadComplete) {
      // Centrar indicador de carga
      return const Center(child: CircularProgressIndicator());
    }
    // Estado de Error Crítico Inicial
    if (viewModel.errorMessage != null && viewModel.vendor == null) {
      return Center( // Centrar widget de error
        child: ErrorStateWidget( // Usar widget separado
            message: viewModel.errorMessage!,
            onRetry: () => viewModel.loadInitialData()
        ),
      );
    }
    // Estado Imposible
    if (viewModel.vendor == null) {
      return const Center(child: Text('Error inesperado: Vendedor no disponible.'));
    }

    // --- Cuerpo Principal con CustomScrollView ---
    return CustomScrollView(
      controller: _scrollController, // Importante para paginación
      physics: const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()), // Mejor feedback de scroll
      slivers: [
        // --- Banner de Error (si aplica) ---
        if (viewModel.errorMessage != null && viewModel.initialLoadComplete)
          SliverToBoxAdapter(child: GeneralErrorBanner( // Usa widget separado
              message: viewModel.errorMessage!,
              onDismiss: () => viewModel.clearErrorMessage()
          )),

        // --- Panel de Estadísticas ---
        SliverToBoxAdapter(child: Padding(
            padding: const EdgeInsets.only(left: 16.0, right: 16.0, top: 16.0), // Padding alrededor
            child: StatsPanel(viewModel: viewModel) // Usa widget separado
        )),
        const SliverToBoxAdapter(child: SizedBox(height: 8)), // Espacio reducido

        // --- Info Vendedor ---
        SliverToBoxAdapter(child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: VendorInfoCard(vendor: viewModel.vendor!) // Usa widget separado
        )),
        const SliverToBoxAdapter(child: SizedBox(height: 24)),

        // --- Meta de Ventas ---
        if (viewModel.currentGoal != null) ...[
          SliverToBoxAdapter(child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: SalesGoalCard(currentGoal: viewModel.currentGoal!) // Usa widget separado
          )),
          const SliverToBoxAdapter(child: SizedBox(height: 24)),
        ],

        // --- Sección Próximas Visitas ---
        SliverToBoxAdapter(child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: SectionHeader('Próximas Visitas', onViewAllPressed: () => print("TODO: Nav Todas Visitas")))), // Usa widget separado
        SliverToBoxAdapter(child: VisitFilterChips(viewModel: viewModel)), // Usa widget separado
        VisitList(viewModel: viewModel), // Usa widget lista separado
        const SliverToBoxAdapter(child: SizedBox(height: 24)),

        // --- Sección Clientes Asignados ---
        SliverToBoxAdapter(child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: SectionHeader('Clientes Asignados', onViewAllPressed: () => print("TODO: Nav Todos Clientes")))), // Usa widget separado
        SliverToBoxAdapter(child: CustomerFilterChips(viewModel: viewModel)), // Usa widget separado
        CustomerList(viewModel: viewModel), // Usa widget lista separado

        // Padding inferior para que el FAB no tape el botón "Cargar más"
        const SliverToBoxAdapter(child: SizedBox(height: 88)),
      ],
    );
  }
} // Fin _VendorDashboardViewState

// ================================================================
// WIDGETS DE UI PRIVADOS DE ESTA PANTALLA (Si los hubiera)
// O puedes mover AppBarTitle y ConnectivityIcon a widgets/ también
// ================================================================

class _AppBarTitle extends StatelessWidget {
  final Vendor? vendor;
  const _AppBarTitle({this.vendor});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Image.asset('assets/images/logo.png', height: 30,
          errorBuilder: (_, __, ___) => Icon(Icons.business, color: theme.colorScheme.onPrimary),),
        const SizedBox(width: 10),
        Flexible(child: Text('Gtronic Vendedor',
          style: Theme.of(context).textTheme.titleLarge?.copyWith(color: theme.colorScheme.onPrimary),
          overflow: TextOverflow.ellipsis,),),
      ],);
  }
}

class _ConnectivityIcon extends StatelessWidget {
  final bool isOffline;
  const _ConnectivityIcon({required this.isOffline});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.only(right: 8.0),
      child: Tooltip(message: isOffline ? 'Trabajando sin conexión' : 'Conectado',
        child: Icon(isOffline ? Icons.signal_wifi_off_rounded : Icons.signal_wifi_4_bar_rounded,
          color: isOffline ? Colors.orange.shade300 : theme.colorScheme.onPrimary.withOpacity(0.9), size: 20,),),);
  }
}