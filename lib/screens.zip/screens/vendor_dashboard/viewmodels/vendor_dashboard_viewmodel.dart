i// lib/screens/vendor_dashboard/viewmodels/vendor_dashboard_viewmodel.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:collection/collection.dart';

// --- Modelos (subir DOS niveles a lib, bajar a models) ---
import '../../models/vendor_model.dart';
import '../../models/client_model.dart';
import '../../models/visit_model.dart';
import '../../models/sales_goal_model.dart';

// --- Servicios (subir DOS niveles a lib, bajar a services) ---
import '../../services/vendor_service.dart';
import '../../services/visit_service.dart';
import '../../services/customer_service.dart'; // O client_service.dart si ese es tu nombre!
// import '../../utils/helpers.dart'; // Si tienes helpers

// --- Enums para Filtros ---
enum VisitFilterType { upcoming, today, thisWeek, alerts }
enum CustomerFilterType { all, news } // TODO: Implementar más filtros

// --- Clases auxiliares ---
class VisitQueryResult {
  final List<Visit> visits;
  final DocumentSnapshot? lastDocument;
  final bool hasMore;
  VisitQueryResult({required this.visits, this.lastDocument, required this.hasMore});
}
class CustomerQueryResult {
  final List<Customer> customers;
  final DocumentSnapshot? lastDocument;
  final bool hasMore;
  CustomerQueryResult({required this.customers, this.lastDocument, required this.hasMore});
}

// --- ViewModel ---
class VendorDashboardViewModel extends ChangeNotifier {
  // --- Dependencias ---
  final String vendorId;
  final VendorService _vendorService = VendorService(); // TODO: Inyectar
  final VisitService _visitService = VisitService();     // TODO: Inyectar
  final CustomerService _customerService = CustomerService(); // TODO: Inyectar

  // --- Estado Interno ---
  bool _isLoading = true;
  String? _errorMessage;
  bool _isOffline = false;
  bool _initialLoadComplete = false;
  Vendor? _vendor;
  SalesGoal? _currentGoal;
  List<Visit> _visits = [];
  List<Customer> _customers = [];
  Map<String, Customer> _customerCache = {};
  DocumentSnapshot? _lastVisitDoc;
  DocumentSnapshot? _lastCustomerDoc;
  bool _hasMoreVisits = true;
  bool _hasMoreCustomers = true;
  bool _isFetchingMoreVisits = false;
  bool _isFetchingMoreCustomers = false;
  VisitFilterType _selectedVisitFilter = VisitFilterType.upcoming;
  CustomerFilterType _selectedCustomerFilter = CustomerFilterType.all; // Placeholder
  StreamSubscription? _connectivitySubscription;
  int _visitsTodayCount = 0;
  int _newCustomersCount = 0;
  double _salesToday = 0;

  // --- Getters Públicos ---
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  bool get isOffline => _isOffline;
  bool get initialLoadComplete => _initialLoadComplete;
  Vendor? get vendor => _vendor;
  SalesGoal? get currentGoal => _currentGoal;
  List<Visit> get displayVisits => List.unmodifiable(_visits);
  List<Customer> get displayCustomers => List.unmodifiable(_customers);
  Customer? getCachedCustomer(String id) => _customerCache[id];
  bool get isFetchingMoreVisits => _isFetchingMoreVisits;
  bool get isFetchingMoreCustomers => _isFetchingMoreCustomers;
  bool get hasMoreVisits => _hasMoreVisits;
  bool get hasMoreCustomers => _hasMoreCustomers;
  VisitFilterType get selectedVisitFilter => _selectedVisitFilter;
  CustomerFilterType get selectedCustomerFilter => _selectedCustomerFilter;
  int get visitsTodayCount => _visitsTodayCount;
  int get newCustomersCount => _newCustomersCount;
  double get salesToday => _salesToday;

  // --- Constructor e Inicialización ---
  VendorDashboardViewModel({required this.vendorId}) {
    print("ViewModel Initialized for Vendor: $vendorId");
    _initialize();
  }

  Future<void> _initialize() async {
    await loadInitialData();
    _listenToConnectivity();
  }

  @override
  void dispose() {
    print("ViewModel Disposed");
    _connectivitySubscription?.cancel();
    super.dispose();
  }

  // --- Lógica Principal ---
  Future<void> loadInitialData({bool refresh = false}) async {
    if (_isLoading && !refresh) return; // Evita cargas múltiples
    _isLoading = true;
    if (refresh) _errorMessage = null;
    notifyListeners();

    _lastVisitDoc = null; _hasMoreVisits = true;
    _lastCustomerDoc = null; _hasMoreCustomers = true;

    try {
      if (_isOffline && _initialLoadComplete && !refresh) {
        print("Offline, showing cached data (simulation).");
        _isLoading = false; notifyListeners(); return;
      }

      // Carga inicial
      final results = await Future.wait([
        _vendorService.getVendorById(vendorId),
        _vendorService.getCurrentSalesGoalForVendor(vendorId),
        _loadInitialCustomers(10), // Carga clientes y cachea
        _loadInitialVisits(10),     // Carga visitas iniciales
        _calculateStats(),         // Calcula stats
      ]).timeout(const Duration(seconds: 25)); // Aumentar timeout por si acaso

      _vendor = results[0] as Vendor?;
      _currentGoal = results[1] as SalesGoal?;
      // Las listas y flags de paginación se actualizaron dentro de los métodos llamados

      if (_vendor == null) _errorMessage = "Vendedor no encontrado.";
      _initialLoadComplete = true;

    } catch (e, s) {
      print("Error loading initial dashboard data: $e\n$s");
      _errorMessage = "Error al cargar datos. Verifica tu conexión.";
      _vendor = null; _currentGoal = null; _visits = []; _customers = []; _customerCache = {};
      _hasMoreCustomers = false; _hasMoreVisits = false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<CustomerQueryResult> _loadInitialCustomers(int limit) async {
    final result = await _customerService.getCustomersByVendorId(
        vendorId, limit: limit, filter: _selectedCustomerFilter // Pasa filtro
    );
    _customers = result.customers; // Establece la lista inicial
    _customerCache = { for (var c in _customers) c.id : c }; // Llena caché inicial
    _lastCustomerDoc = result.lastDocument;
    _hasMoreCustomers = result.hasMore;
    _sortLists(); // Ordena la lista inicial
    return result;
  }

  Future<VisitQueryResult> _loadInitialVisits(int limit) async {
    final result = await _visitService.getUpcomingVisitsByVendorId(
        vendorId, limit: limit, filter: _selectedVisitFilter // Pasa filtro
    );
    _visits = result.visits; // Establece la lista inicial
    _lastVisitDoc = result.lastDocument;
    _hasMoreVisits = result.hasMore;
    await _eagerLoadCustomersForVisits(_visits); // Carga clientes para estas visitas
    _sortLists(); // Ordena la lista inicial
    return result;
  }

  Future<void> loadMoreVisits() async {
    if (_isFetchingMoreVisits || !_hasMoreVisits || _isOffline) return;
    _isFetchingMoreVisits = true; notifyListeners();
    print("Attempting to load more visits after: ${_lastVisitDoc?.id}");
    try {
      final result = await _visitService.getUpcomingVisitsByVendorId( vendorId,
          limit: 10, startAfterDoc: _lastVisitDoc, filter: _selectedVisitFilter );
      await _eagerLoadCustomersForVisits(result.visits);
      _visits.addAll(result.visits); // Añade a la lista
      _lastVisitDoc = result.lastDocument; _hasMoreVisits = result.hasMore; _sortLists();
    } catch (e) { print("Error loading more visits: $e"); _errorMessage = "Error cargando más visitas."; }
    finally { _isFetchingMoreVisits = false; notifyListeners(); }
  }

  Future<void> loadMoreCustomers() async {
    if (_isFetchingMoreCustomers || !_hasMoreCustomers || _isOffline) return;
    _isFetchingMoreCustomers = true; notifyListeners();
    print("Attempting to load more customers after: ${_lastCustomerDoc?.id}");
    try {
      final result = await _customerService.getCustomersByVendorId( vendorId,
          limit: 10, startAfterDoc: _lastCustomerDoc, filter: _selectedCustomerFilter ); // Usa filtro
      _customers.addAll(result.customers); // Añade a la lista
      _customerCache.addAll({ for (var c in result.customers) c.id : c }); // Actualiza caché
      _lastCustomerDoc = result.lastDocument; _hasMoreCustomers = result.hasMore; _sortLists();
    } catch (e) { print("Error loading more customers: $e"); _errorMessage = "Error cargando más clientes."; }
    finally { _isFetchingMoreCustomers = false; notifyListeners(); }
  }

  Future<void> _eagerLoadCustomersForVisits(List<Visit> visits) async {
    final neededIds = visits.map((v) => v.customerId).where((id) => !_customerCache.containsKey(id)).toSet().toList();
    if (neededIds.isNotEmpty) {
      print("Eager loading customers: $neededIds");
      try {
        final fetched = await _customerService.getCustomersByIds(neededIds); // NECESITA ESTE MÉTODO EN SERVICIO
        _customerCache.addAll(fetched);
        // No notificamos necesariamente, la UI usará la caché actualizada al renderizar VisitCard
      } catch (e) { print("Error eager loading customers: $e"); }
    }
  }

  Future<void> applyVisitFilter(VisitFilterType newFilter) async {
    if (_selectedVisitFilter == newFilter || _isLoading || _isFetchingMoreVisits) return; // Evita cambios durante carga
    _selectedVisitFilter = newFilter;
    print("Applying visit filter: $newFilter - Reloading data...");
    await loadInitialData(refresh: true); // Recarga todo al cambiar filtro por ahora
  }

  Future<void> applyCustomerFilter(CustomerFilterType newFilter) async {
    if (_selectedCustomerFilter == newFilter || _isLoading || _isFetchingMoreCustomers) return;
    _selectedCustomerFilter = newFilter;
    print("Applying customer filter: $newFilter - Reloading data...");
    await loadInitialData(refresh: true);
  }

  Future<void> acknowledgeNewClient(String customerId) async {
    if (_isOffline) { _showOfflineMessage("actualizar cliente"); return; }
    final index = _customers.indexWhere((c) => c.id == customerId);
    if (index != -1) {
      final original = _customers[index];
      // Actualización optimista
      _customers[index] = original.copyWith(acknowledgedByVendor: true, isNewlyAssigned: false);
      _customerCache[customerId] = _customers[index]; _sortLists(); notifyListeners();
      try {
        await _customerService.acknowledgeAssignment(customerId, vendorId); await _calculateStats();
      } catch (e) { print("Error ack client: $e"); _errorMessage = "Error al act. cliente."; _customers[index] = original; _customerCache[customerId] = original; _sortLists(); notifyListeners(); }
    }
  }

  Future<void> deactivateVisitAlert(String visitId) async {
    if (_isOffline) { _showOfflineMessage("actualizar visita"); return; }
    final index = _visits.indexWhere((v) => v.id == visitId);
    if (index != -1) {
      final original = _visits[index];
      // Actualización optimista
      _visits[index] = original.copyWith(isAlertActive: false); _sortLists(); notifyListeners();
      try { await _visitService.deactivateAlert(visitId); await _calculateStats(); }
      catch (e) { print("Error deact alert: $e"); _errorMessage = "Error al act. visita."; _visits[index] = original; _sortLists(); notifyListeners(); }
    }
  }

  Future<void> _calculateStats() async {
    if (_isOffline && !_initialLoadComplete) return;
    try {
      // TODO: Implementar llamadas reales a servicios que hagan counts/sums en Firestore
      _visitsTodayCount = await _visitService.countVisitsForToday(vendorId);
      _newCustomersCount = await _customerService.countNewAssignments(vendorId);
      _salesToday = await _vendorService.getSalesAmountForPeriod(vendorId, DateTime.now());
    } catch(e) { print("Error calculating stats: $e"); _visitsTodayCount=0; _newCustomersCount=0; _salesToday=0; }
    notifyListeners(); // Notifica aunque haya error para resetear a 0
  }

  void _listenToConnectivity() {
    try {
      Connectivity().checkConnectivity().then((r) {_isOffline = r.contains(ConnectivityResult.none); notifyListeners();});
      _connectivitySubscription = Connectivity().onConnectivityChanged.listen((List<ConnectivityResult> results) {
        final bool currentlyOffline = results.contains(ConnectivityResult.none);
        if (_isOffline != currentlyOffline) {
          _isOffline = currentlyOffline; print("Conn: ${isOffline ? 'OFF' : 'ON'}"); notifyListeners();
          if (!isOffline && _initialLoadComplete) { print("Conn restored, refreshing..."); loadInitialData(refresh: true); }
          else if (!isOffline && !_initialLoadComplete) { print("First time online, loading..."); loadInitialData(); }
        }
      });
    } catch (e) { print("Connectivity listener error: $e"); _isOffline = false; }
  }

  void _sortLists() {
    _visits.sort((a, b) { bool aA = (a.isAdminAlert ?? false) && (a.isAlertActive ?? true); bool bA = (b.isAdminAlert ?? false) && (b.isAlertActive ?? true); if (aA && !bA) return -1; if (!aA && bA) return 1; return a.date.compareTo(b.date); });
    _customers.sort((a, b) { bool aP = (a.isNewlyAssigned ?? false) || !(a.acknowledgedByVendor ?? true); bool bP = (b.isNewlyAssigned ?? false) || !(b.acknowledgedByVendor ?? true); if (aP && !bP) return -1; if (!aP && bP) return 1; return a.businessName.toLowerCase().compareTo(b.businessName.toLowerCase()); });
  }

  void _showOfflineMessage(String action) {
    _errorMessage = "Necesitas conexión para $action."; notifyListeners();
    Future.delayed(const Duration(seconds: 4), () { if (_errorMessage == "Necesitas conexión para $action.") { _errorMessage = null; notifyListeners(); }});
  }

  void clearErrorMessage() { if (_errorMessage != null) { _errorMessage = null; notifyListeners(); } }

} // Fin VendorDashboardViewModel

// --- Extensiones (Mover a utils/helpers.dart o models/*_extensions.dart) ---
extension VisitExtensions on Visit { bool get isAlertActiveReal => (isAdminAlert ?? false) && (isAlertActive ?? true); }
extension CustomerExtensions on Customer { bool get isPendingAcknowledgement => (isNewlyAssigned ?? false) || !(acknowledgedByVendor ?? true); }