class ErrorHandler {
  static void handleError(dynamic error) {
    print('Error: $error');
    // Implementa aquí tu lógica de manejo de errores
  }
}