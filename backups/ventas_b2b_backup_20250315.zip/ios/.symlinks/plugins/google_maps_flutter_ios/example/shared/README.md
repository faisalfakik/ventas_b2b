This directory contains shared code used by all of the example apps.
