# sqflite_example

Demonstrates how to use the [sqflite plugin](https://github.com/tekartik/sqflite).

## Quick test

Create project
```
flutter create --platforms=macos,ios .
```

Run
```
flutter run
```
