import 'package:flutter_test/flutter_test.dart';

// Keep a dummy file to avoid it be created again each time
void main() {
  testWidgets('dummy', (WidgetTester tester) async {});
}
